def parrot():
    pass
